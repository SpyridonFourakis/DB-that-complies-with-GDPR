<?php
/**
 * Created by PhpStorm.
 * User: Ilias
 * Date: 5/6/2018
 * Time: 5:33 μμ
 */
?>

<h2>Deletion message sent!</h2>
