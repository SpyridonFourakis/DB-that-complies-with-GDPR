<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => '',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '0',
  'commentsAsLabels' => '0',
);
