<?php
return array (
  'template' => 'default',
  'baseControllerClass' => 'MessageController',
);
